from django.db import models

class Customer(models.Model):
    firstname = models.CharField(max_length=50)
    lastname = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    password = models.CharField(max_length=5000)

    def register(self):
        self.save()
    
    # for login checking
    @staticmethod
    def get_customer_by_email(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False


    @staticmethod
    def get_all_customers():
        return Product.objects.all()
    

    # Retrive all the emails and check if it exists
    def isExists(self):
        if Customer.objects.filter(email = self.email):
            return True
        
        return False
    # Retrive all the mobile numbers and check if it exists
    def ismobileExists(self):
        if Customer.objects.filter(phone = self.phone):
            return True
        
        return False