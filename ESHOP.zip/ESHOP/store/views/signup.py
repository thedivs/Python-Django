from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View

class Signup(View):
	def get(self,request):
		return render(request, 'signup.html')
	
	def post(self,request):
		postData = request.POST
		firstname = postData.get('firstname') 
		lastname = postData.get('lastname')
		phone = postData.get('phone')
		email = postData.get('email')
		password = postData.get('password')
		
		# Validation
		value = {
			'firstname' : firstname , 
			'lastname'  : lastname,
			'phone'     : phone,
			'email'		: email
			}

		error_msg = None

		customer = Customer(firstname=firstname,
							lastname = lastname,
							phone = phone,
							email = email,
							password = password)

		error_msg = self.validateCustomer(customer)
		# saving
		if not error_msg:
			customer.password = make_password(customer.password)
			customer.register()
			return redirect('homepage')
		else:
			data = {
			'error' : error_msg,
			'values' : value
			}
			return render(request, 'signup.html',data)

	def validateCustomer(self,customer):
		error_msg = None
		if(not customer.firstname):
			error_msg = "First Name Required !"
		elif len(customer.firstname)<4:
			error_msg = "First name must be 4 charcter long !"
		elif not customer.lastname:
			error_msg = "Last Name Required !"
		elif len(customer.lastname)<4:
			error_msg = "Last name must be 4 charcter long !"
		elif not customer.phone:
			error_msg = "Phone Number Required !"
		elif len(customer.phone)<10:
			error_msg = "Phone number must be 10 char long !"
		elif not customer.email:
			error_msg = "Email Address is required !"
		elif len(customer.email)<10:
			error_msg = "Email must be 10 char long !"
		elif not customer.password:
			error_msg = "Password is required !"
		elif len(customer.password)<4:
			error_msg = "Password must be 4 char long !"
		elif customer.isExists():
			error_msg = 'Email Address is already registered!'
		elif customer.ismobileExists():
			error_msg = 'Mobile Number is already registered!'

		return error_msg

	